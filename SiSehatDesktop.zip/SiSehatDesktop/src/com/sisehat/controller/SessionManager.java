package com.sisehat.controller;

import com.sisehat.model.User;

public class SessionManager {
    public static User currentUser;
}